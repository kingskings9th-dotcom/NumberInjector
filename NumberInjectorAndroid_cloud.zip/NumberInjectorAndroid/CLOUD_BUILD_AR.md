# بناء APK من الهاتف فقط

هذه النسخة مجهزة لـ GitHub Actions. لا تحتاج Android Studio.

1. أنشئ حسابًا في GitHub من الهاتف.
2. أنشئ Repository جديدًا باسم NumberInjector، واجعله Public أو Private.
3. ارفع كل محتويات هذا المجلد إلى المستودع (لا ترفع ملف ZIP نفسه فقط).
4. افتح تبويب Actions ثم اختر Build APK ثم Run workflow.
5. انتظر حتى تنتهي المهمة بنجاح.
6. افتح صفحة المهمة، ثم قسم Artifacts، وحمّل NumberInjector-debug-apk.zip.
7. فك ضغطه وستجد app-debug.apk.

ملاحظة: هذا APK تجريبي (debug). عند تثبيته على الهاتف قد تحتاج السماح بالتثبيت من هذا المصدر.
