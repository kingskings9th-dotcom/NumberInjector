package com.example.numberinjector
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.gravity=Gravity.CENTER
  val title=TextView(this); title.text="إدخال الأرقام تلقائيًا"; title.textSize=24f
  val nums=EditText(this); nums.hint="اكتب الأرقام هنا"; nums.setText("1234567890")
  val rate=EditText(this); rate.hint="عدد الأرقام في الثانية"; rate.setText("1000"); rate.inputType=2
  val start=Button(this); start.text="▶ ابدأ"
  val stop=Button(this); stop.text="⏹ إيقاف"
  val settings=Button(this); settings.text="تفعيل خدمة إمكانية الوصول"
  settings.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
  start.setOnClickListener { NumberAccessibilityService.text=nums.text.toString(); NumberAccessibilityService.running=true }
  stop.setOnClickListener { NumberAccessibilityService.running=false }
  box.addView(title); box.addView(nums); box.addView(rate); box.addView(start); box.addView(stop); box.addView(settings)
  setContentView(box)
 }
}