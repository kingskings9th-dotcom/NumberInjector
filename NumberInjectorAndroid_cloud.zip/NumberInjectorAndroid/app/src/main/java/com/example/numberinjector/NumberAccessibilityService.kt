package com.example.numberinjector
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper
import android.os.Bundle

class NumberAccessibilityService: AccessibilityService() {
 companion object { @Volatile var text="1234567890"; @Volatile var running=false }
 private val h=Handler(Looper.getMainLooper())
 override fun onAccessibilityEvent(event: AccessibilityEvent?) {
  if(!running) return
  val root=rootInActiveWindow ?: return
  val node=findEditable(root) ?: return
  val args=Bundle()
  args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
  node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)
  running=false
 }
 private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
  if(n.isEditable) return n
  for(i in 0 until n.childCount) n.getChild(i)?.let { r=findEditable(it); if(r!=null) return r }
  return null
 }
 override fun onInterrupt() {}
}